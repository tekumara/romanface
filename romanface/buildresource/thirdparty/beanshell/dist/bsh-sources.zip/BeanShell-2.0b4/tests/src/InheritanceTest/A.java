package InheritanceTest;

public interface A {
	void a();
}
